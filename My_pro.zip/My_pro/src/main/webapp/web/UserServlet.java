import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class BlogServlet extends HttpServlet {
    private Connection conn;

    public void init() throws ServletException {
        // Initialize the connection to the database
        conn = YourDatabaseConnectionClass.getConnection();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests (e.g., displaying records)
        // Retrieve data from the database and forward to JSP for presentation
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle POST requests (e.g., adding, updating, deleting records)
        // Perform corresponding CRUD operation and then redirect or forward to appropriate page
    }

    public void destroy() {
        // Close database connection when servlet is destroyed
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
